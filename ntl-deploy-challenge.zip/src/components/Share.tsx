import { Twitter, Mail } from "lucide-react";

export default function Share() {
  const tweetText = `Hey @netlify!

I completed your deploy challenge! Check out my site.`;
  const emailSubject = "NTL DEPLOY Challenge Completed";
  const emailBody =
    "Hey Netlify team! I completed your deploy challenge! Check out my site.";

  const shareOnTwitter = () => {
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(
      tweetText,
    )}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const sendEmail = () => {
    const url = `mailto:devexperience@netlify.com?subject=${encodeURIComponent(
      emailSubject,
    )}&body=${encodeURIComponent(emailBody)}`;
    window.location.href = url;
  };

  return (
    <section
      id="share"
      className="min-h-screen flex items-center justify-center px-6 bg-neutral-900 text-white"
    >
      <div className="max-w-4xl mx-auto text-center w-full">
        <p className="text-xl md:text-2xl font-text mb-8 text-neutral-200 max-w-2xl mx-auto">
          Share your site on social with #AgentRunnersOnNetlify (or email us if you don't have social) to
          complete the challenge.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
          {/* Twitter Share Button */}
          <button
            onClick={shareOnTwitter}
            className="flex items-center gap-3 bg-blue-500 hover:bg-blue-400 text-white font-display font-semibold text-lg px-8 py-4 rounded-full transition-colors duration-200 shadow-lg hover:shadow-xl cursor-pointer"
          >
            <Twitter size={20} />
            Share on X
          </button>

          {/* Email Button */}
          <button
            onClick={sendEmail}
            className="flex items-center gap-3 bg-neutral-700 hover:bg-neutral-600 text-white font-display font-semibold text-lg px-8 py-4 rounded-full transition-colors duration-200 shadow-lg hover:shadow-xl cursor-pointer"
          >
            <Mail size={20} />
            Email us instead
          </button>
        </div>

        {/* Happy Building Section */}
        <div className="pt-16">
          <h2 className="text-3xl md:text-[2.75rem] font-display font-bold mb-8 text-white">
            Happy building!
          </h2>

          <div className="flex justify-center">
            <a
              href="https://www.netlify.com/"
              target="_blank"
              rel="noopener noreferrer"
              className="transition-opacity hover:opacity-80"
            >
              <svg
                width="256"
                height="105"
                viewBox="0 0 256 105"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="w-auto h-12"
              >
                <g clipPath="url(#clip0_236_43)">
                  <path
                    d="M58.4704 103.765V77.4144L59.0165 76.8683H65.6043L66.1504 77.4144V103.765L65.6043 104.311H59.0165L58.4704 103.765Z"
                    fill="#32E6E2"
                  />
                  <path
                    d="M58.4704 26.8971V0.546133L59.0165 0H65.6043L66.1504 0.546133V26.8971L65.6043 27.4432H59.0165L58.4704 26.8971Z"
                    fill="#32E6E2"
                  />
                  <path
                    d="M35.7973 85.2395H34.8928L30.3616 80.7083V79.8037L38.8523 71.3045L43.648 71.3131L44.288 71.9445V76.7403L35.7973 85.2395Z"
                    fill="#32E6E2"
                  />
                  <path
                    d="M30.3616 24.7467V23.8336L34.8928 19.3109H35.7973L44.288 27.8016V32.5888L43.648 33.2373H38.8523L30.3616 24.7467Z"
                    fill="#32E6E2"
                  />
                  <path
                    d="M0.546133 48.3072H37.8795L38.4256 48.8533V55.4496L37.8795 55.9958H0.546133L0 55.4496V48.8533L0.546133 48.3072Z"
                    fill="#32E6E2"
                  />
                  <path
                    d="M255.445 48.3157L255.991 48.8619V55.4496L255.445 55.9957H217.566L217.02 55.4496L219.759 48.8619L220.305 48.3157H255.445Z"
                    fill="#32E6E2"
                  />
                  <path
                    d="M74.6667 65.8859H68.0789L67.5328 65.3397V49.92C67.5328 47.1723 66.4576 45.0475 63.1467 44.9792C61.44 44.9365 59.4944 44.9792 57.4123 45.0645L57.0965 45.3803V65.3312L56.5504 65.8773H49.9627L49.4165 65.3312V38.9803L49.9627 38.4341H64.7851C70.5451 38.4341 75.2128 43.1019 75.2128 48.8619V65.3312L74.6667 65.8773V65.8859Z"
                    fill="white"
                  />
                  <path
                    d="M106.573 54.3488L106.027 54.8949H88.9941L88.448 55.4411C88.448 56.5419 89.5488 59.8357 93.9435 59.8357C95.5904 59.8357 97.2373 59.2896 97.792 58.1888L98.3381 57.6427H104.926L105.472 58.1888C104.926 61.4827 102.178 66.432 93.9349 66.432C84.5995 66.432 80.2048 59.8443 80.2048 52.1472C80.2048 44.4501 84.5995 37.8624 93.3888 37.8624C102.178 37.8624 106.573 44.4501 106.573 52.1472V54.3488ZM98.3296 48.8533C98.3296 48.3072 97.7835 44.4587 93.3888 44.4587C88.9941 44.4587 88.448 48.3072 88.448 48.8533L88.9941 49.3995H97.7835L98.3296 48.8533Z"
                    fill="white"
                  />
                  <path
                    d="M121.95 57.6427C121.95 58.7435 122.496 59.2896 123.597 59.2896H128.538L129.084 59.8358V65.3312L128.538 65.8773H123.597C118.656 65.8773 114.261 63.6758 114.261 57.6342V45.5509L113.715 45.0048H109.867L109.321 44.4587V38.9632L109.867 38.4171H113.715L114.261 37.8709V32.9301L114.807 32.384H121.395L121.941 32.9301V37.8709L122.487 38.4171H128.529L129.075 38.9632V44.4587L128.529 45.0048H122.487L121.941 45.5509V57.6342L121.95 57.6427Z"
                    fill="white"
                  />
                  <path
                    d="M142.276 65.8859H135.689L135.142 65.3397V27.9808L135.689 27.4347H142.276L142.822 27.9808V65.3312L142.276 65.8773V65.8859Z"
                    fill="white"
                  />
                  <path
                    d="M157.107 34.0224H150.519L149.973 33.4763V27.9808L150.519 27.4347H157.107L157.653 27.9808V33.4763L157.107 34.0224ZM157.107 65.8859H150.519L149.973 65.3397V38.9717L150.519 38.4256H157.107L157.653 38.9717V65.3397L157.107 65.8859Z"
                    fill="white"
                  />
                  <path
                    d="M182.929 27.9808V33.4763L182.383 34.0224H177.442C176.341 34.0224 175.795 34.5685 175.795 35.6693V37.8709L176.341 38.4171H181.837L182.383 38.9632V44.4587L181.837 45.0048H176.341L175.795 45.5509V65.3227L175.249 65.8688H168.661L168.115 65.3227V45.5509L167.569 45.0048H163.721L163.174 44.4587V38.9632L163.721 38.4171H167.569L168.115 37.8709V35.6693C168.115 29.6277 172.51 27.4261 177.451 27.4261H182.391L182.938 27.9723L182.929 27.9808Z"
                    fill="white"
                  />
                  <path
                    d="M203.247 66.432C201.045 71.9275 198.852 75.2213 191.164 75.2213H188.416L187.87 74.6752V69.1797L188.416 68.6336H191.164C193.911 68.6336 194.458 68.0875 195.012 66.4405V65.8944L186.223 44.4672V38.9717L186.769 38.4256H191.71L192.256 38.9717L198.844 57.6512H199.39L205.978 38.9717L206.524 38.4256H211.465L212.011 38.9717V44.4672L203.221 66.4405L203.247 66.432Z"
                    fill="white"
                  />
                </g>
                <defs>
                  <clipPath id="clip0_236_43_share">
                    <rect width="256" height="104.311" fill="white" />
                  </clipPath>
                </defs>
              </svg>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
