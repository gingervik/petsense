const NetlifyLogo = () => (
  <svg
    width="256"
    height="105"
    viewBox="0 0 256 105"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className="w-auto h-15"
  >
    <g clipPath="url(#clip0_236_43)">
      <path
        d="M58.4704 103.765V77.4144L59.0165 76.8683H65.6043L66.1504 77.4144V103.765L65.6043 104.311H59.0165L58.4704 103.765Z"
        fill="#32E6E2"
      />
      <path
        d="M58.4704 26.8971V0.546133L59.0165 0H65.6043L66.1504 0.546133V26.8971L65.6043 27.4432H59.0165L58.4704 26.8971Z"
        fill="#32E6E2"
      />
      <path
        d="M35.7973 85.2395H34.8928L30.3616 80.7083V79.8037L38.8523 71.3045L43.648 71.3131L44.288 71.9445V76.7403L35.7973 85.2395Z"
        fill="#32E6E2"
      />
      <path
        d="M30.3616 24.7467V23.8336L34.8928 19.3109H35.7973L44.288 27.8016V32.5888L43.648 33.2373H38.8523L30.3616 24.7467Z"
        fill="#32E6E2"
      />
      <path
        d="M0.546133 48.3072H37.8795L38.4256 48.8533V55.4496L37.8795 55.9958H0.546133L0 55.4496V48.8533L0.546133 48.3072Z"
        fill="#32E6E2"
      />
      <path
        d="M255.445 48.3157L255.991 48.8619V55.4496L255.445 55.9957H217.566L217.02 55.4496L219.759 48.8619L220.305 48.3157H255.445Z"
        fill="#32E6E2"
      />
      <path
        d="M74.6667 65.8859H68.0789L67.5328 65.3397V49.92C67.5328 47.1723 66.4576 45.0475 63.1467 44.9792C61.44 44.9365 59.4944 44.9792 57.4123 45.0645L57.0965 45.3803V65.3312L56.5504 65.8773H49.9627L49.4165 65.3312V38.9803L49.9627 38.4341H64.7851C70.5451 38.4341 75.2128 43.1019 75.2128 48.8619V65.3312L74.6667 65.8773V65.8859Z"
        fill="white"
      />
      <path
        d="M106.573 54.3488L106.027 54.8949H88.9941L88.448 55.4411C88.448 56.5419 89.5488 59.8357 93.9435 59.8357C95.5904 59.8357 97.2373 59.2896 97.792 58.1888L98.3381 57.6427H104.926L105.472 58.1888C104.926 61.4827 102.178 66.432 93.9349 66.432C84.5995 66.432 80.2048 59.8443 80.2048 52.1472C80.2048 44.4501 84.5995 37.8624 93.3888 37.8624C102.178 37.8624 106.573 44.4501 106.573 52.1472V54.3488ZM98.3296 48.8533C98.3296 48.3072 97.7835 44.4587 93.3888 44.4587C88.9941 44.4587 88.448 48.3072 88.448 48.8533L88.9941 49.3995H97.7835L98.3296 48.8533Z"
        fill="white"
      />
      <path
        d="M121.95 57.6427C121.95 58.7435 122.496 59.2896 123.597 59.2896H128.538L129.084 59.8358V65.3312L128.538 65.8773H123.597C118.656 65.8773 114.261 63.6758 114.261 57.6342V45.5509L113.715 45.0048H109.867L109.321 44.4587V38.9632L109.867 38.4171H113.715L114.261 37.8709V32.9301L114.807 32.384H121.395L121.941 32.9301V37.8709L122.487 38.4171H128.529L129.075 38.9632V44.4587L128.529 45.0048H122.487L121.941 45.5509V57.6342L121.95 57.6427Z"
        fill="white"
      />
      <path
        d="M142.276 65.8859H135.689L135.142 65.3397V27.9808L135.689 27.4347H142.276L142.822 27.9808V65.3312L142.276 65.8773V65.8859Z"
        fill="white"
      />
      <path
        d="M157.107 34.0224H150.519L149.973 33.4763V27.9808L150.519 27.4347H157.107L157.653 27.9808V33.4763L157.107 34.0224ZM157.107 65.8859H150.519L149.973 65.3397V38.9717L150.519 38.4256H157.107L157.653 38.9717V65.3397L157.107 65.8859Z"
        fill="white"
      />
      <path
        d="M182.929 27.9808V33.4763L182.383 34.0224H177.442C176.341 34.0224 175.795 34.5685 175.795 35.6693V37.8709L176.341 38.4171H181.837L182.383 38.9632V44.4587L181.837 45.0048H176.341L175.795 45.5509V65.3227L175.249 65.8688H168.661L168.115 65.3227V45.5509L167.569 45.0048H163.721L163.174 44.4587V38.9632L163.721 38.4171H167.569L168.115 37.8709V35.6693C168.115 29.6277 172.51 27.4261 177.451 27.4261H182.391L182.938 27.9723L182.929 27.9808Z"
        fill="white"
      />
      <path
        d="M203.247 66.432C201.045 71.9275 198.852 75.2213 191.164 75.2213H188.416L187.87 74.6752V69.1797L188.416 68.6336H191.164C193.911 68.6336 194.458 68.0875 195.012 66.4405V65.8944L186.223 44.4672V38.9717L186.769 38.4256H191.71L192.256 38.9717L198.844 57.6512H199.39L205.978 38.9717L206.524 38.4256H211.465L212.011 38.9717V44.4672L203.221 66.4405L203.247 66.432Z"
        fill="white"
      />
    </g>
    <defs>
      <clipPath id="clip0_236_43">
        <rect width="256" height="104.311" fill="white" />
      </clipPath>
    </defs>
  </svg>
);

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-b from-teal-900 via-neutral-800 to-neutral-900">
      {/* Texture Background */}
      <div
        className="absolute inset-0 opacity-40"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.15'%3E%3Ccircle cx='10' cy='10' r='0.5'/%3E%3Ccircle cx='2' cy='2' r='0.3'/%3E%3Ccircle cx='18' cy='8' r='0.4'/%3E%3Ccircle cx='6' cy='16' r='0.3'/%3E%3Ccircle cx='14' cy='4' r='0.4'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          backgroundSize: "15px 15px",
        }}
      />

      {/* Grid Pattern Overlay */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 0h100v1H0V0zm0 10h100v1H0V10zm0 10h100v1H0V20zm0 10h100v1H0V30zm0 10h100v1H0V40zm0 10h100v1H0V50zm0 10h100v1H0V60zm0 10h100v1H0V70zm0 10h100v1H0V80zm0 10h100v1H0V90zM0 0v100h1V0H0zm10 0v100h1V0H10zm10 0v100h1V0H20zm10 0v100h1V0H30zm10 0v100h1V0H40zm10 0v100h1V0H50zm10 0v100h1V0H60zm10 0v100h1V0H70zm10 0v100h1V0H80zm10 0v100h1V0H90z' fill='%23ffffff' fill-opacity='0.05'/%3E%3C/svg%3E")`,
          backgroundSize: "50px 50px",
        }}
      />

      {/* Content */}
      <div className="relative z-10 text-center text-white px-6 max-w-4xl">
        {/* Logo */}
        <div className="mb-8 flex justify-center">
          <a
            href="https://www.netlify.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="transition-opacity hover:opacity-80"
          >
            <NetlifyLogo />
          </a>
        </div>

        {/* Main Title */}
        <h1 className="text-6xl md:text-8xl font-display font-bold mb-6 leading-tight">
          Deploy Challenge
        </h1>

        {/* Subtitle */}
        <p className="text-xl md:text-2xl text-neutral-300 font-text max-w-3xl mx-auto leading-relaxed mb-8">
          Follow the instructions below to complete the deploy challenge and
          claim your prize
        </p>

        {/* CTA Button */}
        <div className="flex justify-center">
          <button
            onClick={() => {
              document.getElementById("instructions")?.scrollIntoView({
                behavior: "smooth",
              });
            }}
            className="bg-teal-400 hover:bg-teal-300 text-neutral-900 font-display font-semibold text-lg px-8 py-4 rounded-full transition-colors duration-200 shadow-lg hover:shadow-xl inline-flex items-center gap-2 cursor-pointer"
          >
            Start Challenge
            <svg
              className="w-4 h-4 animate-bounce"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M19 14l-7 7m0 0l-7-7m7 7V3"
              />
            </svg>
          </button>
        </div>
      </div>
    </section>
  );
}
